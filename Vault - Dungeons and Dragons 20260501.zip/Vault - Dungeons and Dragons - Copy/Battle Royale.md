Ladies and gentlemen these fine fighters before you are the ONLY survivors from their proving grounds! They've certainly given themselves a lot to live up to, so today they'll be facing off against a loving care taker and his three best trained Wasps! But First! A word from our sponsor, [[Warden Blacksmithing]]! Take delight in your very own Orc slaying sword, magically enchanted to stay sharp for at least one year, and for a premium payout make it glow whenever one comes near you! [[Mauriel]], send out the combatants! 
Level 3 - Fight 1:
3 [[Giant Wasps]]
1 Bugbear stalker

Level 3 - Fight 2:
1 green dragon wyrmling

level 4 - Fight 1:
1 Green Half Dragon
2 green cowering kobolds, with torn up wings.

Level 6 - Fight 1