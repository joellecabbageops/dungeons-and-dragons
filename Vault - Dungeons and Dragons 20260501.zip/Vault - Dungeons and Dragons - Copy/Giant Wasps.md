> [!monster]+ **Giant Wasp**
> *Medium beast, unaligned*
> 
> **Armor Class** 12  
> **Hit Points** 13 (3d8)  
> **Speed** 10 ft., fly 50 ft.
> 
> | STR     | DEX     | CON     | INT     | WIS     | CHA     |
> |---------|---------|---------|---------|---------|---------|
> | 10 (+0) | 14 (+2) | 10 (+0) | 1 (-5)  | 10 (+0) | 3 (-4)  |
> 
> **Senses** passive Perception 10  
> **Challenge** 1/2 (100 XP)
> 
> ---
> 
> ### Actions
> 
> **Sting.** *Melee Weapon Attack:* +4 to hit, reach 5 ft., one creature.  
> *Hit:* 4 (1d6 + 2) piercing damage plus 10 (3d6) poison damage.  
> The target must make a **DC 11 Constitution saving throw**, taking the poison damage on a failed save, or half as much damage on a successful one.  
> If the poison damage reduces the target to 0 hit points, the target is stable but **poisoned for 1 hour**, even after regaining hit points, and is **paralyzed** while poisoned in this way.