[[Minor Arena chests]].
